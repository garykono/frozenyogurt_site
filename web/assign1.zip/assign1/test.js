let x = [4, 2, 3];

x.splice(0, 1);

console.log(x[0]);