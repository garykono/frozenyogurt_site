window.onload = function() {
    //Initialize session storage
    sessionStorage.setItem("customers", "[]");
    sessionStorage.setItem("currentCustomer", "-1");
}